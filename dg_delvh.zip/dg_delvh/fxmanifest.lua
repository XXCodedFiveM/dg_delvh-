fx_version 'cerulean'
game 'gta5'

author 'dotty_gg'
description 'Vehicle delete HUD | DV'
version '1.0'

ui_page 'html/index.html'

client_script 'client.lua'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
