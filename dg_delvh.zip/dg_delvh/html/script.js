window.addEventListener("message", function(event) {
    if (event.data.action === "show") {
        const hud = document.getElementById("hud");
        const hudText = document.getElementById("hud-text");

        hudText.innerHTML = event.data.text;
        hudText.style.color = event.data.color;
        hud.style.display = "block";
    } else if (event.data.action === "hide") {
        document.getElementById("hud").style.display = "none";
    }
});
