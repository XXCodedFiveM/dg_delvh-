RegisterNUICallback("hideHud", function() 
    SendNUIMessage({ action = "hide" }) 
end)

RegisterCommand("dv", function()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    local message = ""
    local color = "red"

    if vehicle ~= 0 then
        NetworkRequestControlOfEntity(vehicle)
        SetEntityAsMissionEntity(vehicle, true, true)
        DeleteVehicle(vehicle)
        DeleteEntity(vehicle)

        message = "Vehicle Deleted"
        color = "green"
        PlaySoundFromEntity(-1, "SELECT", playerPed, "HUD_LIQUOR_STORE_SOUNDSET", 0, 0)
    else
        local result, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())
        if result and IsEntityAVehicle(entity) then
            NetworkRequestControlOfEntity(entity)
            SetEntityAsMissionEntity(entity, true, true)
            DeleteVehicle(entity)
            DeleteEntity(entity)

            message = "Vehicle Deleted"
            color = "green"
            PlaySoundFromEntity(-1, "SELECT", playerPed, "HUD_LIQUOR_STORE_SOUNDSET", 0, 0)
        else
            message = "No Vehicle Found"
        end
    end

    SendNUIMessage({
        action = "show",
        text = message,
        color = color
    })

    Citizen.SetTimeout(3000, function()
        SendNUIMessage({ action = "hide" })
    end)
end, false)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        local screenWidth, screenHeight = GetScreenResolution()
        local hudPosX = screenWidth * 0.5
        local hudPosY = screenHeight * 0.75

        SetTextFont(0)
        SetTextProportional(1)
        SetTextScale(0.4, 0.4)
        SetTextColour(255, 255, 255, 255)
        BeginTextCommandDisplayText("STRING")
        AddTextComponentSubstringPlayerName("Vehicle Deleted")
        EndTextCommandDisplayText(hudPosX, hudPosY)
    end
end)
